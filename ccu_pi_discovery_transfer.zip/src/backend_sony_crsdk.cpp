#include "backend_sony_crsdk.h"
#include <string.h>

static CrSdkCfg g_cfg;
static bool g_debug = false;
static bool g_has_target = false;
static IPAddress g_target_ip;
static EthernetUDP g_udp;
static uint32_t g_seq = 1;
static bool g_sent_boot_options = false;
static CamRecState g_last_rec_state[CCU_MAX_CAMS];
static uint32_t g_last_status_ms = 0;
static bool g_poll_enabled = true;
static bool g_poll_active = true;
static uint32_t g_poll_active_ms = 250;
static uint32_t g_poll_idle_ms = 1500;

static constexpr uint32_t CCU1_MAGIC = 0x43435531u; // 'CCU1'
static constexpr uint8_t  CCU1_VER = 1;
static constexpr uint8_t  CCU1_MSG_REQUEST = 0x01;
static constexpr uint8_t  CCU1_MSG_RESPONSE = 0x81;

static constexpr uint8_t CMD_RUNSTOP     = 0x10;
static constexpr uint8_t CMD_GET_OPTIONS = 0x20;
static constexpr uint8_t CMD_GET_STATUS  = 0x30;
static constexpr uint8_t CMD_CAPTURE_STILL = 0x31;
static constexpr uint8_t CMD_DISCOVER   = 0x32;
static constexpr uint8_t CMD_SET_VALUE   = 0x40; // reserved (future)
static constexpr uint8_t CMD_PARAM_STEP  = 0x41; // reserved (future)

static constexpr uint8_t OPT_ISO         = 0x01;
static constexpr uint8_t OPT_WHITE_BAL   = 0x02;
static constexpr uint8_t OPT_SHUTTER     = 0x03;
static constexpr uint8_t OPT_FPS         = 0x04;
static constexpr uint8_t OPT_PROJECT_FPS = 0x05; // extension for project fps lists

static bool cfg_has_ip() {
  return !(g_cfg.manual_ip == IPAddress(0, 0, 0, 0));
}

static void wr_u16_le(uint8_t* p, uint16_t v) {
  p[0] = (uint8_t)(v & 0xFF);
  p[1] = (uint8_t)((v >> 8) & 0xFF);
}

static void wr_u32_le(uint8_t* p, uint32_t v) {
  p[0] = (uint8_t)(v & 0xFF);
  p[1] = (uint8_t)((v >> 8) & 0xFF);
  p[2] = (uint8_t)((v >> 16) & 0xFF);
  p[3] = (uint8_t)((v >> 24) & 0xFF);
}

static uint16_t rd_u16_le(const uint8_t* p) {
  return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
}

static uint32_t rd_u32_le(const uint8_t* p) {
  return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

// CRC32 IEEE (reflected), poly 0xEDB88320
static uint32_t crc32_ieee(const uint8_t* data, size_t len) {
  uint32_t crc = 0xFFFFFFFFu;
  for (size_t i = 0; i < len; i++) {
    crc ^= data[i];
    for (int b = 0; b < 8; b++) {
      uint32_t mask = (uint32_t)-(int)(crc & 1u);
      crc = (crc >> 1) ^ (0xEDB88320u & mask);
    }
  }
  return ~crc;
}

static uint8_t cam_mask(uint8_t cam_idx) {
  if (cam_idx >= 8) return 0;
  return (uint8_t)(1u << cam_idx);
}

static void apply_option_value(uint8_t opt_id, uint32_t cur, CamState& c) {
  switch (opt_id) {
    case OPT_ISO:
      c.p.supports_iso = true;
      c.p.iso_valid = true;
      c.p.iso_value = (int32_t)cur;
      c.pend_iso = false;
      break;
    case OPT_WHITE_BAL:
      c.p.supports_wb = true;
      c.p.wb_valid = true;
      c.p.wb_kelvin = (int32_t)cur;
      c.pend_wb = false;
      break;
    case OPT_FPS:
      c.p.supports_fps = true;
      c.p.fps_valid = true;
      c.p.fps_milli = (cur < 1000u) ? (int32_t)(cur * 1000u) : (int32_t)cur;
      c.pend_fps = false;
      break;
    case OPT_SHUTTER:
      c.p.supports_shutter = true;
      c.p.shutter_valid = true;
      if (cur <= 360u) c.p.shutter_mdeg = (int32_t)(cur * 1000u);
      else c.p.shutter_mdeg = (int32_t)cur;
      c.pend_sh = false;
      break;
    default:
      break;
  }
}

static void crsdk_send_ccu1(uint8_t cmd, uint8_t target_mask, const uint8_t* payload, uint16_t payload_len) {
  if (!g_cfg.enabled) return;
  if (!cfg_has_ip()) return;

  constexpr uint16_t HDR_LEN = 16;
  uint8_t buf[HDR_LEN + 32 + 4]; // header + payload + CRC32
  if (payload_len > 32) return;

  wr_u32_le(buf + 0, CCU1_MAGIC);
  buf[4] = CCU1_VER;
  buf[5] = CCU1_MSG_REQUEST;
  wr_u16_le(buf + 6, payload_len);
  wr_u32_le(buf + 8, g_seq++);
  buf[12] = target_mask;
  buf[13] = cmd;
  wr_u16_le(buf + 14, 0); // flags

  if (payload_len && payload) memcpy(buf + HDR_LEN, payload, payload_len);

  const uint16_t total_no_crc = (uint16_t)(HDR_LEN + payload_len);
  const uint32_t crc = crc32_ieee(buf, total_no_crc);
  wr_u32_le(buf + total_no_crc, crc);

  g_udp.beginPacket(g_cfg.manual_ip, g_cfg.port);
  g_udp.write(buf, total_no_crc + 4);
  g_udp.endPacket();

  if (g_debug) {
    Serial.print("CRSDK CCU1 -> ");
    Serial.print(g_cfg.manual_ip);
    Serial.print(":");
    Serial.print(g_cfg.port);
    Serial.print(" cmd=0x");
    Serial.print(cmd, HEX);
    Serial.print(" len=");
    Serial.println(payload_len);
  }
}

static void crsdk_send_runstop(uint8_t target_mask, uint8_t action) {
  uint8_t payload[1] = { action };
  crsdk_send_ccu1(CMD_RUNSTOP, target_mask, payload, sizeof(payload));
}

static void crsdk_send_get_options(uint8_t target_mask, uint8_t opt_id) {
  uint8_t payload[1] = { opt_id };
  crsdk_send_ccu1(CMD_GET_OPTIONS, target_mask, payload, sizeof(payload));
}

static void crsdk_send_get_status(uint8_t target_mask) {
  crsdk_send_ccu1(CMD_GET_STATUS, target_mask, nullptr, 0);
}

static void crsdk_send_capture_still(uint8_t target_mask, bool with_af) {
  uint8_t payload[1] = { with_af ? (uint8_t)1 : (uint8_t)0 };
  crsdk_send_ccu1(CMD_CAPTURE_STILL, target_mask, payload, sizeof(payload));
}

static void crsdk_send_set_value(uint8_t target_mask, uint8_t param_id, int32_t value) {
  uint8_t payload[5];
  payload[0] = param_id;
  wr_u32_le(payload + 1, (uint32_t)value);
  crsdk_send_ccu1(CMD_SET_VALUE, target_mask, payload, sizeof(payload));
}

static void crsdk_send_param_step(uint8_t target_mask, uint8_t param_id, int8_t step) {
  uint8_t payload[2];
  payload[0] = param_id;
  payload[1] = (uint8_t)step;
  crsdk_send_ccu1(CMD_PARAM_STEP, target_mask, payload, sizeof(payload));
}

void crsdk_backend_init(const CrSdkCfg& cfg) {
  g_cfg = cfg;
  g_has_target = false;
  g_target_ip = IPAddress(0, 0, 0, 0);
  g_sent_boot_options = false;
  g_last_status_ms = 0;
  for (uint8_t i = 0; i < CCU_MAX_CAMS; i++) g_last_rec_state[i] = REC_UNKNOWN;
  if (!g_cfg.enabled) return;
  g_udp.begin(g_cfg.local_port);
}

void crsdk_backend_set_debug(bool on) { g_debug = on; }

bool crsdk_backend_has_target() {
  return g_has_target || !(g_cfg.manual_ip == IPAddress(0,0,0,0));
}

IPAddress crsdk_backend_target_ip() {
  if (!(g_cfg.manual_ip == IPAddress(0,0,0,0))) return g_cfg.manual_ip;
  return g_target_ip;
}

void crsdk_backend_tick(CamState cams[CCU_MAX_CAMS], uint32_t now_ms) {
  (void)now_ms;
  if (!g_cfg.enabled) return;
  if (g_cfg.cam_idx >= CCU_MAX_CAMS) return;

  CamState& c = cams[g_cfg.cam_idx];
  // Placeholder: mark as connected while UDP bridge is enabled.
  c.conn = CAM_READY;

  // Poll for CCU1 responses from Pi
  int pkt = g_udp.parsePacket();
  while (pkt > 0) {
    uint8_t buf[512];
    int n = g_udp.read(buf, (int)sizeof(buf));
    if (n > 0) {
      const size_t len = (size_t)n;
      if (len >= 20) { // header + crc minimum
        const uint32_t magic = rd_u32_le(buf + 0);
        const uint8_t ver = buf[4];
        const uint8_t msg_type = buf[5];
        const uint16_t payload_len = rd_u16_le(buf + 6);
        const uint32_t seq = rd_u32_le(buf + 8);
        const uint8_t target_mask = buf[12];
        const uint8_t code = buf[13];
        (void)seq;
        (void)target_mask;

        if (magic == CCU1_MAGIC && ver == CCU1_VER && msg_type == CCU1_MSG_RESPONSE) {
          const size_t expected = (size_t)16 + (size_t)payload_len + 4u;
          if (expected == len) {
            const uint32_t got_crc = rd_u32_le(buf + 16 + payload_len);
            const uint32_t calc_crc = crc32_ieee(buf, 16 + payload_len);
            if (got_crc == calc_crc) {
              g_has_target = true;
              c.last_rx_ms = now_ms;

              const uint8_t* pl = buf + 16;
              if (payload_len == 8) {
                const uint8_t ok_mask = pl[0];
                const uint8_t fail_mask = pl[1];
                const uint8_t busy_mask = pl[2];
                const uint8_t state_run_mask = pl[3];
                const uint8_t state_known_mask = pl[4];
                (void)ok_mask; (void)fail_mask; (void)busy_mask; (void)code;

                const uint8_t bit = cam_mask(g_cfg.cam_idx);
                if (state_known_mask & bit) {
                  const bool is_rec = (state_run_mask & bit) != 0;
                  c.rec = is_rec ? REC_RECORDING : REC_IDLE;
                  g_last_rec_state[g_cfg.cam_idx] = c.rec;
                  c.pend_rec = false;
                }
              } else if (payload_len == 44) {
                const uint32_t battery_level = rd_u32_le(pl + 0);
                const uint32_t battery_remain = rd_u32_le(pl + 4);
                const uint32_t battery_unit = rd_u32_le(pl + 8);
                const uint32_t media_slot1_time = rd_u32_le(pl + 28);
                const uint32_t media_slot2_time = rd_u32_le(pl + 40);
                (void)battery_unit;

                if (battery_level != 0xFFFFFFFFu || battery_remain != 0xFFFFFFFFu) {
                  const uint32_t pct = (battery_remain != 0xFFFFFFFFu) ? battery_remain : battery_level;
                  c.p.battery_valid = true;
                  c.p.battery_pct = (int32_t)pct;
                } else {
                  c.p.battery_valid = false;
                }

                const uint32_t mt = (media_slot1_time != 0xFFFFFFFFu) ? media_slot1_time : media_slot2_time;
                if (mt != 0xFFFFFFFFu) {
                  c.p.media_time_valid = true;
                  c.p.media_time_min = (int32_t)mt;
                  c.p.media_valid = false;
                } else {
                  c.p.media_time_valid = false;
                }
              } else if (payload_len >= 9) {
                const uint8_t opt_id = pl[0];
                const uint32_t cur = rd_u32_le(pl + 5);
                apply_option_value(opt_id, cur, c);
              }
            }
          }
        }
      }
    }
    pkt = g_udp.parsePacket();
  }

  if (!g_sent_boot_options) {
    g_sent_boot_options = true;
    const uint16_t mask = cam_mask(g_cfg.cam_idx);
    crsdk_send_get_options(mask, OPT_ISO);
    crsdk_send_get_options(mask, OPT_WHITE_BAL);
    crsdk_send_get_options(mask, OPT_SHUTTER);
    crsdk_send_get_options(mask, OPT_FPS);
    crsdk_send_get_options(mask, OPT_PROJECT_FPS);
  }

  if (g_poll_enabled) {
    const uint32_t interval = g_poll_active ? g_poll_active_ms : g_poll_idle_ms;
    if (interval > 0 && now_ms - g_last_status_ms >= interval) {
      g_last_status_ms = now_ms;
      crsdk_send_get_status(cam_mask(g_cfg.cam_idx));
    }
  }

  if (g_debug) {
    // One-time hint; avoid spamming.
    static bool once = false;
    if (!once) {
      once = true;
      Serial.println("CRSDK: UDP bridge active");
    }
  }
}

void crsdk_set_iso(uint16_t iso) {
  crsdk_send_set_value(cam_mask(g_cfg.cam_idx), OPT_ISO, (int32_t)iso);
}

void crsdk_set_wb(uint16_t kelvin) {
  crsdk_send_set_value(cam_mask(g_cfg.cam_idx), OPT_WHITE_BAL, (int32_t)kelvin);
}

void crsdk_set_fps(uint16_t fps) {
  crsdk_send_set_value(cam_mask(g_cfg.cam_idx), OPT_FPS, (int32_t)fps);
}

void crsdk_set_shutter_angle(uint16_t angle_deg) {
  crsdk_send_set_value(cam_mask(g_cfg.cam_idx), OPT_SHUTTER, (int32_t)angle_deg);
}

void crsdk_set_project_fps(int32_t fps_milli) {
  crsdk_send_set_value(cam_mask(g_cfg.cam_idx), OPT_PROJECT_FPS, fps_milli);
}

void crsdk_set_record(bool rec) {
  crsdk_send_runstop(cam_mask(g_cfg.cam_idx), rec ? 0x01 : 0x00);
}

void crsdk_capture_still(bool with_af) {
  crsdk_send_capture_still(cam_mask(g_cfg.cam_idx), with_af);
}

void crsdk_request_status(uint8_t cam_idx) {
  crsdk_send_get_status(cam_mask(cam_idx));
}

void crsdk_request_status_mask(uint8_t target_mask) {
  crsdk_send_get_status(target_mask);
}

void crsdk_request_discover() {
  crsdk_send_ccu1(CMD_DISCOVER, 0xFF, nullptr, 0);
}

void crsdk_set_poll_enabled(bool enabled) {
  g_poll_enabled = enabled;
}

void crsdk_set_poll_active(bool active) {
  g_poll_active = active;
}

void crsdk_set_iso_step(uint8_t cam_idx, int8_t step) {
  crsdk_send_param_step(cam_mask(cam_idx), OPT_ISO, step);
}

void crsdk_set_wb_kelvin(uint8_t cam_idx, uint16_t kelvin) {
  crsdk_send_set_value(cam_mask(cam_idx), OPT_WHITE_BAL, (int32_t)kelvin);
}

void crsdk_rec_toggle(uint8_t cam_idx) {
  const CamRecState cur = g_last_rec_state[cam_idx];
  const bool want_rec = (cur != REC_RECORDING);
  crsdk_send_runstop(cam_mask(cam_idx), want_rec ? 0x01 : 0x00);
}
