#pragma once
#include <Arduino.h>
#include <stdint.h>

// -------------------------------
// Constants
// -------------------------------
static constexpr uint8_t  CCU_MAX_CAMS = 8;

// -------------------------------
// Camera connection + health
// -------------------------------
enum CamConnState : uint8_t {
  CAM_DISCONNECTED = 0,
  CAM_CONNECTING   = 1,
  CAM_AUTH         = 2,
  CAM_READY        = 3,
  CAM_FAULT        = 4,
};

enum CamRecState : uint8_t {
  REC_UNKNOWN    = 0,
  REC_IDLE       = 1,
  REC_RECORDING  = 2,
  REC_STARTING   = 3,   // optional
  REC_FINALIZING = 4,   // optional
};

// Parameter "quality" for group display
enum GroupQuality : uint8_t {
  GQ_UNKNOWN = 0,
  GQ_UNIFIED = 1,
  GQ_MIXED   = 2,
  GQ_PENDING = 3,
  GQ_PARTIAL = 4,
  GQ_UNAVAILABLE = 5,
};

enum CamType : uint8_t {
  CAM_TYPE_UNKNOWN = 0,
  CAM_TYPE_RED_RAPTOR,
  CAM_TYPE_RED_RAPTOR_XL,
  CAM_TYPE_RED_KOMODO,
  CAM_TYPE_RED_KOMODO_X,
  CAM_TYPE_SONY_FR7,
  CAM_TYPE_SONY_VENICE,
  CAM_TYPE_SONY_VENICE2,
  CAM_TYPE_SONY_BURANO,
  CAM_TYPE_SONY_A7IV,
  CAM_TYPE_SONY_FX6,
  CAM_TYPE_SONY_FX3,
};

// Which "focus param" the encoder is editing
enum FocusParam : uint8_t {
  FP_ISO = 0,
  FP_WB  = 1,
  FP_FPS = 2,
  FP_SHUTTER = 3,
  FP_COUNT
};

// Target selection for control actions
enum TargetSel : uint8_t {
  TGT_A = 0, TGT_B, TGT_C, TGT_D, TGT_E, TGT_F, TGT_G, TGT_H,
  TGT_ALL = 8,
};

enum TargetMode : uint8_t {
  TM_ALL = 0,
  TM_SELECT = 1,
  TM_SINGLE = 2,
};

// -------------------------------
// Common parameter bundle
// (store as "display-ready" values; each backend owns mapping)
// -------------------------------
struct CamParams {
  bool     supports_iso = true;
  bool     supports_wb = true;
  bool     supports_fps = true;
  bool     supports_shutter = true;

  bool     iso_valid = false;
  int32_t  iso_value = 0;          // e.g. 800

  bool     wb_valid  = false;
  int32_t  wb_kelvin = 0;          // e.g. 5600

  bool     fps_valid = false;
  int32_t  fps_milli = 0;          // e.g. 23976 (23.976 fps)

  bool     shutter_valid = false;
  int32_t  shutter_mdeg  = 0;      // shutter angle in milli-degrees (e.g. 180000)

  bool     proj_fps_valid = false;
  int32_t  proj_fps_milli = 0;     // project time base, milli-fps if provided
  char     proj_fps_str[12] = {0}; // display string fallback

  bool     proj_fmt_valid = false;
  int32_t  proj_fmt = 0;
  char     proj_fmt_str[12] = {0};

  bool     r3d_quality_valid = false;
  int32_t  r3d_quality = 0;
  char     r3d_quality_str[10] = {0};

  bool     tc_valid = false;
  char     tc_str[16] = {0};

  bool     genlock_valid = false;
  int32_t  genlock_state = 0;

  bool     sync_valid = false;
  int32_t  sync_state = 0;

  bool     media_valid = false;
  int32_t  media_pct = 0;

  bool     battery_valid = false;
  int32_t  battery_pct = 0;

  bool     media_time_valid = false;
  int32_t  media_time_min = 0;
};

// -------------------------------
// Per-camera state tracked by coordinator
// -------------------------------
struct CamState {
  // Identity
  char     label = 'A';            // 'A'..'H'
  uint32_t ip_v4 = 0;              // store as host order uint32 if you want
  CamType  type = CAM_TYPE_UNKNOWN;

  // Connection
  CamConnState conn = CAM_DISCONNECTED;
  uint32_t     last_rx_ms = 0;     // last time we got ANY camera update
  uint32_t     last_err_ms = 0;
  char         last_err[28] = {0}; // short string shown on roster OLED
  char         model[12] = {0};    // camera model label if known

  // Record + params
  CamRecState  rec = REC_UNKNOWN;
  CamParams    p;

  // Pending confirmation flags (set by multi-cam actions)
  bool         pend_rec = false;
  bool         pend_iso = false;
  bool         pend_wb  = false;
  bool         pend_fps = false;
  bool         pend_sh  = false;

  uint32_t     pend_deadline_ms = 0; // shared deadline for current action (simple)
};

// -------------------------------
// Group aggregate state (for OLED #1 banner)
// -------------------------------
struct GroupState {
  TargetSel    target = TGT_A;
  bool         target_is_group = false;  // ALL or group preset (future)
  TargetMode   mode = TM_ALL;
  uint8_t      select_mask = 0; // bit per cam (A=bit0)
  uint8_t      roster_cursor = 0;
  bool         roster_type_edit = false;

  // Derived “quality” per parameter for ALL mode
  GroupQuality q_rec = GQ_UNKNOWN;
  GroupQuality q_iso = GQ_UNKNOWN;
  GroupQuality q_wb  = GQ_UNKNOWN;
  GroupQuality q_fps = GQ_UNKNOWN;
  GroupQuality q_sh  = GQ_UNKNOWN;

  // Useful UI flags
  bool         any_fault = false;
  bool         any_pending = false;
  bool         mixed_any = false;
  bool         partial_any = false;
  bool         any_unavail = false;

  FocusParam   focus = FP_ISO;
  bool         shift = false;     // SHIFT button held
  bool         arm   = false;     // latching ARM switch
};

// Persisted UI state (EEPROM)
struct UiPersist {
  uint32_t magic = 0x43435550; // "CCUP"
  uint8_t version = 3;
  uint8_t mode = 0;
  uint8_t target = 0;
  uint8_t select_mask = 0;
  uint8_t roster_cursor = 0;
  uint8_t roster_type_edit = 0;
  uint8_t cam_types[CCU_MAX_CAMS] = {0};
  uint8_t checksum = 0;
};

// Network config (CCU ethernet)
struct NetConfig {
  bool dhcp = false;
  uint8_t ip[4] = {192, 168, 0, 50};
  uint8_t mask[4] = {255, 255, 255, 0};
  uint8_t gw[4] = {192, 168, 0, 1};
};

struct NetPersist {
  uint32_t magic = 0;
  uint8_t version = 0;
  NetConfig cfg;
  uint8_t checksum = 0;
};
