#pragma once
#include <Arduino.h>
#include <QNEthernet.h>
using namespace qindesign::network;
#include "ccu_types.h"

// Stub backend for Sony Camera Remote SDK (CrSDK).
// This is a placeholder so the UI can compile while we wire the real SDK.
struct CrSdkCfg {
  bool      enabled = false;
  bool      auto_discover = true;
  IPAddress manual_ip;           // if set, use this IP (0.0.0.0 = unset)
  uint16_t  port = 5555;         // Pi CCU UDP port
  uint16_t  local_port = 1902;   // UDP source port for bridge
  bool      manual_port = false;
  uint8_t   cam_idx = 3;         // which CamState slot to update
  char      friendly_name[24] = "CCU";
};

void crsdk_backend_init(const CrSdkCfg& cfg);
void crsdk_backend_tick(CamState cams[CCU_MAX_CAMS], uint32_t now_ms);

// Debug / status
void      crsdk_backend_set_debug(bool on);
bool      crsdk_backend_has_target();
IPAddress crsdk_backend_target_ip();

// Basic property setters (to be mapped to CrSDK API later)
void crsdk_set_iso(uint16_t iso);
void crsdk_set_wb(uint16_t kelvin);
void crsdk_set_fps(uint16_t fps);
void crsdk_set_shutter_angle(uint16_t angle_deg);
void crsdk_set_record(bool rec);
void crsdk_set_iso_step(uint8_t cam_idx, int8_t step);
void crsdk_set_wb_kelvin(uint8_t cam_idx, uint16_t kelvin);
void crsdk_rec_toggle(uint8_t cam_idx);
void crsdk_set_project_fps(int32_t fps_milli);
void crsdk_capture_still(bool with_af);
void crsdk_request_status(uint8_t cam_idx);
void crsdk_request_status_mask(uint8_t target_mask);
void crsdk_set_poll_enabled(bool enabled);
void crsdk_set_poll_active(bool active);
void crsdk_request_discover(void);
